﻿namespace LegendsOfValor_TheGuildTrials.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
