﻿namespace MythicLegion
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
